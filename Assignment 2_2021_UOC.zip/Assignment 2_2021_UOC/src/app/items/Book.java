package app.items;

public class Book {

	public String book_name;   //declared in a Class
	public String book_title;
	public int book_code;                 //instant variable has default value 
	                               //cannot re initialize 
	
	public String getDescription(){
		System.out.println("Book name : "+book_name);
		System.out.println("Book Title : "+book_title);
		System.out.println("Book Code : "+book_code);
		
		return book_name;
		
	}


}
