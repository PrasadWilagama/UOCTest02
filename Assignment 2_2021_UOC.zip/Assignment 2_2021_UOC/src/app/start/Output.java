package app.start;

import app.items.Book;
import app.members.Member;

public class Output {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book book1 =new Book();
		book1.book_name ="Madol Duwa";
		book1.book_title="Short Stoires";
		book1.book_code=1;
		
		Book book2 =new Book();
		book2.book_name ="Gamperaliya";
		book2.book_title="Novel";
		book2.book_code=2;
		
		book1.getDescription();
		System.out.println("\n");
		book2.getDescription();
		System.out.println("\n");
		
		
		
		Member member1= new Member();
		member1.name="Prasad";
		member1.birthYear=1999;
		member1.number=1;
    	member1.book=book1;		
		
		Member member2= new Member();
		member2.name="Dananjaya";
		member2.birthYear=2000;
		member2.number=2;
			
		
		Member member3= new Member();
		member3.name="Wilagama";
		member3.birthYear=2000;
		member3.number=3;
		member3.book=book2;		
		

		member1.otherDeatails();
		System.out.println("\n");
		member2.otherDeatails();
		System.out.println("\n");
		member3.otherDeatails();
		
		
	}

}
