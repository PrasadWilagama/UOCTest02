package app.members;

import app.calender.Today;
import app.items.Book;

public class Member {
	
	public String name;
    public short birthYear;
    public int number;
    public Book book;
    
    public int getAge(){
    	
    	int age = Today.currentYear - birthYear;
		return age;    	
    	
    }
    
    public String otherDeatails() {
    	
    	if(book==null) {
    	System.out.println("You dont Have book");
    	System.out.println("Member name : "+name);
    	System.out.println("Age is : "+getAge());
    	System.out.println("Member Number is :"+number);
    	
    	
    	}
    	else {
    		System.out.println("Member name : "+name);
        	System.out.println("Age is : "+getAge());
        	System.out.println("Member Number is : "+number);
        	System.out.println("The Book is : "+book.book_name);
			
		}
    	return name;
    }
       
   
}
