package app.calender;

public class Today {
	
	// we can use static keyword for  methods and variables
	
	public static int currentYear = 2021; // int, and assign it the value 2021
	static short currentMonth = 10;  //short, and assign a valid moth 
	static short currentDay = 8 ;  //short, and assign a valid day 
			
	

}
